class Config:
    MONGO_URI = 'mongodb://localhost:27017/blockchain_monitoring'
